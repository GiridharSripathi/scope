# -*- coding: utf-8 -*-
"""
Created on Thu Nov 28 09:46:36 2019

@author: gsripath
"""

class Parent:
    def func1(self):
        print("this is parent function")
 
class Child(Parent):
    def func1(self):
        print("this is child function")
        
 
ob = Child()
ob.func1()




class Parent:
    def func1(self):
        print("this is parent function")
 
class Child(Parent):
    def func1(self):
        print("this is child function")
        super().func1()
        
 
ob = Child()
ob.func1()