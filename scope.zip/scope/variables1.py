
foo = 1
def func():
    bar = 2
    print(foo)
    print(bar)
    
func()



foo = 1   #global

def func():
    foo = 2   #local
    print(foo)
    
    # global variable still exists and unchanged
    print("This is global :",globals()['foo'])
    print("This is local  :",locals()['foo'])
    
func()



